(function (window, angular) {

    /**
     * Constructs a new instance of the bootstrapper
     *
     * @param {String} appName Name of the app module that needs to be bootstrapped
     * @param {DomNode} element The element that the module needs to be attached to
     * @constructor
     */
    function NgBootstrapper(appName, element) {
        if (!appName || typeof appName !== 'string') {
            throw 'App name should be a string';
        }

        //Will throw an error if the module does not exist
        angular.module(appName);

        if (element === window.document) {
            this.element = document.body;
        } else {
            this.element = element;
        }

        this.appName = appName;
        this.remoteInjectableConfigs = [];

        //Create a new injector for this bootstrapper
        this.injector = angular.injector(window.getBootstrapper.$inject);

        this.injectables = {};
        this.runFunctions = [];
        this.modules = [];
        this.scripts = [];
        this.stylesheets = [];
        this.basePathResolver = function (url) {
            return url;
        };

        //Defer the bootstrapping by setting the name flag
        window.name = 'NG_DEFER_BOOTSTRAP!';

        angular.bootstrap(element, [this.appName]);

        //Reset the bootstrapping defer
        window.name = undefined;
    }

    /**
     * Specify a remote source by setting the name and the location.
     * The sources will be loaded when the bootstrap method is called.
     *
     * @param {String} name The name this data will be known by, the injectable name
     * @param {String} url The url where the data is located
     *
     * @returns {NgBootstrapper} Returns itself for chaining purposes
     */
    NgBootstrapper.prototype.addInjectableFromRemoteLocation = function (name, url) {
        if (typeof name !== 'string') {
            throw 'name should be a string';
        }

        if (typeof url !== 'string') {
            throw 'url should be a string';
        }

        this.remoteInjectableConfigs.push({
            name: name,
            remoteUrl: url
        });

        return this;
    };

    /**
     * Load an external script into the document
     * The urlModifier can be used to get a hold of remoteinjectables that might influence
     * the url of the file, like a base path definition.
     *
     * @param {String} scriptUrl The url of the script to be loaded
     * @param {Function} urlModifier Url modifier to modify the url path based on earlier resolved dependencies
     *
     * @returns {NgBootstrapper} Returns itself for chaining
     */
    NgBootstrapper.prototype.loadScript = function (scriptUrl, urlModifier) {
        if (typeof scriptUrl === 'string') {
            this.scripts.push({
                url: scriptUrl,
                resolve: urlModifier
            });
        }
        return this;
    };

    NgBootstrapper.prototype.loadModule = function (scriptUrl, moduleName, urlModifier) {
        if (typeof scriptUrl === 'string' && typeof moduleName === 'string') {
            this.loadScript(scriptUrl, urlModifier);
            this.modules.push(moduleName);
        }
        return this;
    };

    NgBootstrapper.prototype.execute = function (executeFunction) {
        if (typeof executeFunction === 'function' && executeFunction.call) {
            this.runFunctions.push(executeFunction);
        }
        return this;
    };

    /**
     * Load an external stylesheet and add it to the document head
     * Adds href for the provided url and sets rel to stylesheet and type to text/css.
     * The urlModifier can be used to get a hold of remoteinjectables that might influence
     * the url of the file, like a base path definition.
     *
     * @param {String} stylesheetUrl The url of the stylesheet to be loaded
     * @param {Function} urlModifier Url modifier to modify the url path based on earlier resolved dependencies
     *
     * @returns {NgBootstrapper} Returns itself for chaining
     */
    NgBootstrapper.prototype.loadStylesheet = function (stylesheetUrl, urlModifier) {
        if (typeof stylesheetUrl === 'string') {
            this.stylesheets.push({
                url: stylesheetUrl,
                resolve: urlModifier
            });
        }
        return this;
    };

    /**
     * Execute the ajax calls for the dependencies that are set using one of the add methods
     *
     * @returns {Array} Returns an array of promises that represent the requests
     */
    NgBootstrapper.prototype.executeRemoteCalls = function () {
        var promises = [];
        var $http = this.injector.get('$http');
        var $log = this.injector.get('$log');
        var $q = this.injector.get('$q');

        this.remoteInjectableConfigs.forEach(function (remoteInjectableConfig) {
            var promise = $http.get(remoteInjectableConfig.remoteUrl).then(function (response) {
                return {
                    name: remoteInjectableConfig.name,
                    data: response.data
                };
            }, function (error) {
                $log.error(error);
                return $q.reject(error);
            });
            promises.push(promise);
        });
        return promises;
    };

    /**
     * Creates the factories on the module that will be injected with the external results.
     * It adds a factory to the module that returns the data on the response.
     * It looks for a data property on each of the responses.
     *
     * @param {Object} module Angular module that should be injected into the app
     * @param {Array} responses Array of responses that have been received from the ajax calls.
     */
    NgBootstrapper.prototype.createFactories = function (module, responses) {
        var injectables = this.injectables;
        angular.forEach(responses, function (response) {
            injectables[response.name] = response.data;
            module.factory(response.name, function () {
                return response.data;
            });
        });
    };

    /**
     * Perform the actual bootstrapping. It executes the remote calls and when all of
     * them are successful will create the injectables and bootstrap the app.
     *
     * @returns {NgBootstrapper} Returns itself for chaining purposes
     */
    NgBootstrapper.prototype.bootstrap = function () {
        //Create an injectables module
        var module = this.module = angular.module(this.appName + '.injectables', this.modules);

        var self = this;
        var $q = this.injector.get('$q');
        var scripts = this.scripts;
        var stylesheets = this.stylesheets;
        var element = this.element;
        var injectables = this.injectables;
        var basePathResolver = this.basePathResolver;

        if (this.remoteInjectableConfigs.length > 0) {
            $q.all(this.executeRemoteCalls())
                .then(function (responses) {
                    self.createFactories(module, responses);
                    self.runFunctions.forEach(function (runFunction) {
                        runFunction.call(self, injectables);
                    });
                })
                .then(function () {
                    function getBasePath(urlDef) {
                        var resolverFunction = urlDef.resolve || basePathResolver;
                        return resolverFunction.call(null, urlDef.url, injectables);
                    }

                    addStylesheets(stylesheets.map(getBasePath));
                    addScripts.bind(element)(scripts.map(getBasePath));

                    setIsLoadedFlag();
                })
                .then(function () {
                    resumeBootstrapWhenLoaded.bind(self)();
                });
        } else {
            resumeBootstrapWhenLoaded.bind(self)();
        }

        function setIsLoadedFlag() {
            var loadedElement = document.createElement('script');
            loadedElement.textContent = 'window.ngBootstrapperScriptFilesLoaded = true;';
            element.appendChild(loadedElement);
        }

        function resumeBootstrapWhenLoaded() {
            try {
                this.modules.forEach(function (moduleName) {
                    angular.module(moduleName);
                });
                angular.resumeBootstrap([self.appName + '.injectables']);
            } catch (e) {
                window.setTimeout(resumeBootstrapWhenLoaded.bind(this), 10);
            }
        }

        return this;
    };

    NgBootstrapper.prototype.setBasePathResolver = function (resolverFunction) {
        if (typeof resolverFunction === 'function') {
            this.basePathResolver = resolverFunction;
        }
        return this;
    };

    function addScripts(scriptUrls) {
        scriptUrls.forEach(function (scriptUrl) {
            var scriptElement = document.createElement('script');

            scriptElement.setAttribute('src', scriptUrl);
            this.appendChild(scriptElement);
        }, this);
    }

    function addStylesheets(stylesheetUrls) {
        stylesheetUrls.forEach(function (stylesheetUrl) {
            var stylesheetElement = document.createElement('link');
            stylesheetElement.setAttribute('href', stylesheetUrl);
            stylesheetElement.setAttribute('rel', 'stylesheet');
            stylesheetElement.setAttribute('type', 'text/css');

            document.head.appendChild(stylesheetElement);
        }, this);
    }

    /**
     * Exposed method on the window to get a new bootstrapper.
     *
     * @param {String} appName Name of the app module that needs to be bootstrapped.
     * @param {DomNode} element Dom element that the app will be attached to.
     * @returns {NgBootstrapper} Returns the instance of the bootstrapper.
     */
    window.getBootstrapper = function (appName, element) {
        //Defer the bootstrapping of any apps

        return new NgBootstrapper(appName, element);
    };
    window.getBootstrapper.$inject = ['ng'];
}(window, angular));

window.PEPFARUSERMANAGEMENT = {
    debug: true
};

//==================================================================================
// Config functions
//
function translateConfig($translateProvider) {
    $translateProvider.useStaticFilesLoader({
        prefix: 'i18n/',
        suffix: '.json'
    });
    $translateProvider.preferredLanguage('en');
}
translateConfig.$inject = ['$translateProvider'];

function routerConfig($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/list');

    $stateProvider
        .state('list', {
            url: '/list',
            templateUrl: 'userlist/list.html',
            controller: 'userListController as userList',
            resolve: {
                userFilter: ['userFilterService', function (userFilterService) {
                    return userFilterService.getUserFilter();
                }],
                currentUser: ['currentUserService', function (currentUserService) {
                    return currentUserService.getCurrentUser();
                }],
                userActions: ['userActionsService', function (userActionsService) {
                    return userActionsService.getActions();
                }],
                userTypes: ['userTypesService', function (userTypesService) {
                    return userTypesService.getUserTypes();
                }],
                dataGroups: ['dataGroupsService', function (dataGroupsService) {
                    return dataGroupsService.getDataGroups();
                }]
            }
        })
        .state('add', {
            url: '/add',
            templateUrl: 'adduser/add.html',
            controller: 'addUserController as addUser',
            resolve: {
                userTypes: ['userTypesService', function (userTypesService) {
                    return userTypesService.getUserTypes();
                }],
                userActions: ['userActionsService', function (userActionsService) {
                    return userActionsService.getActions();
                }],
                dataGroups: ['dataGroupsService', function (dataGroupsService) {
                    return dataGroupsService.getDataGroups();
                }],
                currentUser: ['currentUserService', function (currentUserService) {
                    return currentUserService.getCurrentUser();
                }],
                dimensionConstraint: ['categoriesService', function (categoriesService) {
                    return categoriesService.getDimensionConstraint();
                }]
            }
        })
        .state('edit', {
            url: '/edit/{userId}/{username}',
            templateUrl: 'edituser/edit.html',
            controller: 'editUserController as editUser',
            resolve: {
                userTypes: ['userTypesService', function (userTypesService) {
                    return userTypesService.getUserTypes();
                }],
                dataGroups: ['dataGroupsService', function (dataGroupsService) {
                    return dataGroupsService.getDataGroups();
                }],
                userActions: ['userActionsService', function (userActionsService) {
                    return userActionsService.getActions();
                }],
                currentUser: ['currentUserService', function (currentUserService) {
                    return currentUserService.getCurrentUser();
                }],
                dimensionConstraint: ['categoriesService', function (categoriesService) {
                    return categoriesService.getDimensionConstraint();
                }],
                userToEdit: ['$stateParams', 'userService', function ($stateParams, userService) {
                    return userService.getUser($stateParams.userId);
                }],
                userLocale: ['$stateParams', 'userService', function ($stateParams, userService) {
                    return userService.getUserLocale($stateParams.username);
                }]
            },
            params: {
                userId: '',
                username: ''
            }
        })
        .state('noaccess', {
            url: '/noaccess',
            templateUrl: 'noaccess/noaccess.html',
            controller: 'noAccessController as noAccess',
            params: {
                message: 'Your user account does not seem to have the right permissions to access this functionality.'
            }
        });
}
routerConfig.$inject = ['$stateProvider', '$urlRouterProvider'];

function angularUiSelectConfig(uiSelectConfig) {
    uiSelectConfig.theme = 'bootstrap';
}
angularUiSelectConfig.$inject = ['uiSelectConfig'];

//==================================================================================
// Angular app module definition
//
angular.module('PEPFAR.usermanagement', [
    'ui.router',
    'restangular',
    'pascalprecht.translate',
    'ui.select',
    'ui.bootstrap',
    'ui.validate',
    'ngMessages',
    'd2-headerbar',
    'ngAnimate'
]);

//==================================================================================
// Angular config blocks
//
angular.module('PEPFAR.usermanagement').config(translateConfig);
angular.module('PEPFAR.usermanagement').config(routerConfig);
angular.module('PEPFAR.usermanagement').config(angularUiSelectConfig);
angular.module('PEPFAR.usermanagement').value('SETTINGS', window.PEPFARUSERMANAGEMENT);
angular.module('PEPFAR.usermanagement').config(['$compileProvider', function ($compileProvider) {
    $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|file|tel|data):/);
}]);

//==================================================================================
// Angular run blocks
//
angular.module('PEPFAR.usermanagement').run(['Restangular', 'webappManifest', function (Restangular, webappManifest) {
    var baseUrl = [webappManifest.activities.dhis.href, 'api'].join('/');
    Restangular.setBaseUrl(baseUrl);
}]);

//==================================================================================
// Bootstrap the app manually
//
function basePathResolver(url, injectables) {
    return [injectables.webappManifest.activities.dhis.href, url].join('/');
}

window.getBootstrapper('PEPFAR.usermanagement', document)
    .setBasePathResolver(basePathResolver)
    .addInjectableFromRemoteLocation('webappManifest', 'manifest.webapp')
    .execute(function (injectables) {
        window.dhis2 = window.dhis2 || {};
        window.dhis2.settings = window.dhis2.settings || {};
        window.dhis2.settings.baseUrl = injectables.webappManifest.activities.dhis.href.replace(window.location.origin, '').replace(/^\//, '');
    })
    .loadStylesheet('/dhis-web-commons/css/menu.css')
    .loadScript('/dhis-web-commons/javascripts/dhis2/dhis2.translate.js')
    .loadModule('/dhis-web-commons/javascripts/dhis2/dhis2.menu.js', 'd2Menu')
    .loadScript('/dhis-web-commons/javascripts/dhis2/dhis2.menu.ui.js')
    .bootstrap();

angular.module('PEPFAR.usermanagement').factory('_', function () {
    return _;
});

angular.module('PEPFAR.usermanagement').controller('appController', appController);

function appController($scope, Restangular, webappManifest, errorHandler) {
    var vm = this;

    vm.title = 'User management';
    vm.subTitle = '';
    vm.isLoading = false;
    vm.headerBar = {
        title: '',
        logo: '',
        link: ''
    };

    vm.subTitles = {
        add: 'Invite user',
        list: 'Manage users',
        edit: 'Edit user'
    };

    initialise();

    $scope.$on('$stateChangeStart', function () {
        vm.isLoading = true;
    });
    $scope.$on('$stateChangeSuccess', function (event, toState) {
        vm.isLoading = false;
        vm.currentState = toState.name;
        vm.subTitle = vm.subTitles[toState.name] || '';
    });
    $scope.$on('$stateChangeError', function (event, toState) {
        errorHandler.debug(['Failed to switch to ', toState].join(' '));
        vm.isLoading = false;
    });

    function initialise() {
        Restangular.one('systemSettings')
            .get()
            .then(function (systemSettings) {
                var baseUrl = webappManifest.activities.dhis.href;

                if (systemSettings.keyCustomTopMenuLogo === true) {
                    vm.headerBar.logo = [
                        baseUrl,
                        '/external-static/logo_banner.png'
                    ].join('');
                }
                vm.headerBar.title = systemSettings.applicationTitle || '';
                vm.headerBar.link = [baseUrl, systemSettings.startModule, 'index.action'].join('/');
            });
    }
}
appController.$inject = ['$scope', 'Restangular', 'webappManifest', 'errorHandler'];

angular.module('PEPFAR.usermanagement').service('userTypesService', userTypesService);

function userTypesService($q) {
    var deferred = $q.defer();
    var userTypes = [
        {name: 'Inter-Agency'},
        {name: 'Agency'},
        {name: 'Partner'}
    ];

    deferred.resolve(userTypes);

    return {
        getUserTypes: getUserTypes,
        getUserType: getUserType
    };

    function getUserTypes() {
        return deferred.promise;
    }

    function getUserType(user) {
        var userTypesForMatches = userTypes.map(fixCountryType).reverse();

        return userTypesForMatches.reduce(function (currentType) {
            var userGroupRegex = new RegExp('OU .+? (.+?) ', 'i');
            (user && user.userGroups || []).forEach(function (userGroup) {
                var matches = userGroupRegex.exec(userGroup.name);

                if (matches && (userTypesForMatches.indexOf(matches[1]) >= 0)) {
                    currentType = matches[1];

                    if (currentType.toLowerCase() === 'country') {
                        currentType = 'Inter-Agency';
                    }
                }
            });
            return currentType;
        }, 'Unknown type');

        function fixCountryType(userType) {
            if (userType.name === 'Inter-Agency') {
                return 'Country';
            }
            return userType.name;
        }
    }
}
userTypesService.$inject = ['$q'];

angular.module('PEPFAR.usermanagement').directive('selectUsertype', userTypeSelectDirective);

function userTypeSelectDirective(partnersService, agenciesService, interAgencyService, errorHandler) {
    var directive = {
        restrict: 'E',
        replace: true,
        scope: {
            userTypes: '=',
            user: '='
        },
        templateUrl: 'users/selectusertype.html',
        link: linkFn
    };

    return directive;

    function linkFn(scope) {
        scope.selectbox = {
            placeholder: 'Select user type',
            items: [],
            selected: scope.userType
        };

        //TODO: Should not use parent $scope hack..
        loadValues(scope.$parent && scope.$parent.userOrgUnit && scope.$parent.userOrgUnit.current);

        scope.$on('ORGUNITCHANGED', function (event, data) {
            errorHandler.debug('Reloading types for ', data.name); //jshint ignore:line
            loadValues(data);
            scope.selectbox.selected = undefined;
            scope.user.userType = undefined;
        });

        function loadValues(orgUnit) {
            scope.selectbox.items = [];

            interAgencyService.getUserGroups(orgUnit).then(function (interAgency) {
                scope.userTypes.forEach(function (item) {
                    if (item.name === 'Inter-Agency' &&
                        (interAgency.userUserGroup || interAgency.userUserGroup)) {
                        scope.selectbox.items.push(item);
                    }
                });
            });

            agenciesService.getAgencies(orgUnit).then(function () {
                scope.userTypes.forEach(function (item) {
                    if (item.name === 'Agency') {
                        scope.selectbox.items.push(item);
                    }
                });
            });

            partnersService.getPartners(orgUnit).then(function () {
                scope.userTypes.forEach(function (item) {
                    if (item.name === 'Partner') {
                        scope.selectbox.items.push(item);
                    }
                });
            });
        }
    }
}
userTypeSelectDirective.$inject = ['partnersService', 'agenciesService', 'interAgencyService', 'errorHandler'];

angular.module('PEPFAR.usermanagement').factory('userActionsService', userActionsService);

function userActionsService(Restangular, $q, userTypesService, dataGroupsService, userService,
                            errorHandler) {
    var availableAgencyActions = [
        'Accept data', 'Submit data', 'Manage users'
    ];
    var availableInterAgencyActions = [
        'Accept data', 'Submit data', 'Manage users'
    ];
    var availablePartnerActions =  [
        'Submit data', 'Manage users'
    ];
    var actions = [
        {name: 'Accept data', userRole: 'Data Accepter'},
        {name: 'Submit data', userRole: 'Data Submitter'},
        {name: 'Manage users', userRole: 'User Administrator'},
        {name: 'Read data', userRole: 'Read Only', default: true}
    ];

    var dataEntryRestrictions = {
        'Inter-Agency': {
            SI: [{
                    userRole: 'Data Entry SI Country Team'
                }, {
                    userRole: 'Tracker'
                }],
            EVAL: [{
                    userRole: 'Data Entry EVAL'
                }]
        },
        Agency: {
            SIMS: [{
                    userRole: 'Data Entry SIMS'
                }]
        },
        Partner: {
            SI: [{
                userRole: 'Data Entry SI'
            }],
            EA: [{
                userRole: 'Data Entry EA'
            }]
        }
    };

    var actionRolesLoaded;

    initialise();
    return {
        getActions: getActions
    };

    function initialise() {
        actionRolesLoaded = Restangular.one('userRoles').withHttpConfig({cache: true}).get({
            fields: 'id,name',
            paging: false
        }).then(function (response) {
            var userRoles = response.userRoles;

            actions.forEach(function (action) {
                action.userRoleId = userRoles.reduce(function (current, value) {
                    if (value.name === action.userRole) {
                        return value.id;
                    }
                    return current;
                }, action.userRoleId);
            });

            addUserRolesForDataEntry(userRoles);

        }, errorHandler.errorFn('Failed to load user roles for actions'));
    }

    function getActions() {
        return $q.when(actionRolesLoaded)
            .then(function () {
                return {
                    actions: actions,
                    dataEntryRestrictions: dataEntryRestrictions,
                    getDataEntryRestrictionDataGroups: getDataEntryRestrictionDataGroups,
                    getActionsForUserType: getActionsForUserType,
                    getActionsForUser: getActionsForUser,
                    getUserRolesForUser: getUserRolesForUser,
                    combineSelectedUserRolesWithExisting: combineSelectedUserRolesWithExisting
                };
            });
    }

    function addUserRolesForDataEntry(userRoles) {
        Object.keys(dataEntryRestrictions).forEach(function (userType) {
            Object.keys(dataEntryRestrictions[userType]).forEach(matchUserRolesWithDataGroups(userRoles, userType));
        });

        function matchUserRolesWithDataGroups(userRoles, userType) {
            return function (dataStream) {
                userRoles.forEach(function (userRole) {
                    var dataStreamRoleList = dataEntryRestrictions[userType][dataStream];

                    dataStreamRoleList.forEach(function (dataStreamRole) {
                        if (userRole && userRole.name === dataStreamRole.userRole) {
                            dataStreamRole.userRoleId = userRole.id;
                        }
                    });
                });
            };
        }
    }

    function getAvailableActionsForUserType(userType) {
        if (typeof userType === 'string') {
            userType = userType.toLowerCase();
        }

        switch (userType) {
            case 'agency':
                return availableAgencyActions;
            case 'partner':
                return availablePartnerActions;
            case 'inter-agency':
                return availableInterAgencyActions;
        }
        return [];
    }

    function getActionsForUserType(userType) {
        var availableActions = getAvailableActionsForUserType(userType);

        return actions.filter(function (action) {
            return (availableActions.indexOf(action.name) >= 0) || action.default;
        });
    }

    function getActionsForUser(user) {
        var actions = getActionsForUserType(userTypesService.getUserType(user));
        var userRoles = (user && user.userCredentials && user.userCredentials.userRoles) || [];
        var userRoleIds = userRoles.map(pick('id'));

        return actionRolesLoaded.then(function () {
            actions.forEach(function (action) {
                action.hasAction = hasUserRoleFor(userRoleIds, action);
            });
            return $q.when(actions);
        });
    }

    function hasUserRoleFor(userRoleIds, action) {
        return (userRoleIds.indexOf(action.userRoleId) >= 0);
    }

    function getUserActionsForNames(selectedActions, actions) {
        var userActions;
        var selectedActionNames = Object.keys(selectedActions)
            .map(function (key) {
                if (selectedActions[key] === true) {
                    return key;
                }
            }).filter(function (action) {
                return action && action !== '';
            });

        userActions = (actions || []).filter(function (action) {
            return selectedActionNames.indexOf(action.name) >= 0;
        });

        return userActions;
    }

    function getUserRolesForUser(user, dataGroups, actions) {
        var dataGroupsWithEntry;
        var userRoles;
        var dataEntryRoles;
        var userActions = (user && user.userActions) || [];

        dataGroupsWithEntry = userService.getSelectedDataGroups(user, dataGroups)
            .filter(function (dataGroup) {
                return user.dataGroups && user.dataGroups[dataGroup.name] && user.dataGroups[dataGroup.name].entry === true;
            });

        userRoles = getUserActionsForNames(userActions, actions)
            .map(pick('userRoleId', 'userRole'))
            .filter(has('userRoleId'))
            .map(function (item) {
                return {
                    name: item.userRole,
                    id: item.userRoleId
                };
            });

        dataEntryRoles = dataGroupsWithEntry
            .map(pick('userRoles'))
            .reduce(flatten(), []);

        return userRoles.concat(dataEntryRoles);
    }

    function getAvailableUserRoles(dataGroups, actions) {
        var dataGroupRoles = (dataGroups || [])
            .map(pick('userRoles'))
            .reduce(flatten(), []);

        var actionRoles = (actions || [])
            .filter(has('userRoleId'))
            .map(pick('userRole', 'userRoleId'))
            .map(function (item) {
                return {
                    name: item.userRole,
                    id: item.userRoleId
                };
            });

        return [].concat(dataGroupRoles).concat(actionRoles);
    }

    function combineSelectedUserRolesWithExisting(userToEdit, user, dataGroups, actions) {
        var selectedUserRoles = getUserRolesForUser(user, dataGroups, actions);
        var availableUserRoleIds = getAvailableUserRoles(dataGroups, actions).map(pick('id'));
        var currentUserRoles = (userToEdit.userCredentials && userToEdit.userCredentials.userRoles) || [];
        var userRoleBasis = currentUserRoles.filter(function (userRole) {
            return availableUserRoleIds.indexOf(userRole.id) === -1;
        });

        return [].concat(userRoleBasis).concat(selectedUserRoles);
    }

    function getDataEntryRestrictionDataGroups(userType) {
        var userTypeToCheck = getPreferredNameFormat(userType);
        if (!userTypeToCheck || !dataEntryRestrictions[userTypeToCheck]) { return []; }

        return Object.keys(dataEntryRestrictions[userTypeToCheck]);
    }

    function getPreferredNameFormat(userType) {
        if (!angular.isString(userType)) { return ''; }

        return userType.split('-').map(function (namePart) {
            return namePart.charAt(0).toUpperCase() + namePart.substr(1).toLowerCase();
        }).join('-');
    }

    /**********
     * Array functions
     */
    //TODO: Move this out to utils
    function has(property) {
        return function (item) {
            if (item && item[property]) {
                return true;
            }
            return false;
        };
    }

    function pick(property) {
        var properties = Array.prototype.filter.apply(arguments, [angular.isString]);

        if (properties.length === 1 && angular.isString(property)) {
            return function (item) {
                return item[property];
            };
        }

        return function (item) {
            var result = {};
            Object.keys(item).map(function (key) {
                if (properties.indexOf(key) >= 0) {
                    result[key] = item[key];
                }
            });
            return result;
        };
    }

    function flatten() {
        return function (current, items) {
            return (current || []).concat(items);
        };
    }

}
userActionsService.$inject = ['Restangular', '$q', 'userTypesService', 'dataGroupsService', 'userService', 'errorHandler'];

angular.module('PEPFAR.usermanagement').factory('userStatusService', userStatusService);

function userStatusService(Restangular, $q) {
    return {
        disable: disableUser,
        enable: enableUser
    };

    function disableUser(userId) {
        if (!angular.isString(userId)) {
            return $q.reject('User id is not a string');
        }

        return getUser(userId)
            .then(setUserDisabled)
            .then(saveUser);
    }

    function enableUser(userId) {
        if (!angular.isString(userId)) {
            return $q.reject('User id is not a string');
        }

        return getUser(userId)
            .then(setUserEnabled)
            .then(saveUser);
    }

    function setUserDisabled(user) {
        var userCredentials = user.userCredentials;
        userCredentials.disabled = true;
        return user;
    }

    function setUserEnabled(user) {
        var userCredentials = user.userCredentials;
        userCredentials.disabled = false;
        return user;
    }

    function saveUser(user) {
        return user.put();
    }

    function getUser(userId) {
        return Restangular.all('users')
            .get(userId);
    }
}
userStatusService.$inject = ['Restangular', '$q'];

angular.module('PEPFAR.usermanagement').factory('dataGroupsService', dataGroupsService);

function dataGroupsService($q, Restangular, currentUserService, _, errorHandler) {
    var deferred;
    var dataGroups = [
        {name: 'SI'},
        {name: 'EA'},
        {name: 'SIMS'}
    ];
    var userGroupNameConfig = {prefix: 'Data', suffix: 'access'};
    var userRoleNameConfig = {prefix: 'Data Entry'};

    initialise();
    return {
        getDataGroups: getDataGroups,
        getDataGroupsForUser: getDataGroupsForUser,
        getUserGroups: getUserGroups
    };

    function initialise() {
        deferred = $q.all([loadUserGroups(), loadUserRoles(), currentUserService.getCurrentUser()]).then(function (responses) {
            var currentUser = responses[2];
            var currentUserGroups = currentUser.userGroups || [];
            var currentUserGroupIds = currentUserGroups.map(function (userGroup) {
                return userGroup.id;
            });
            var resultingDataStreams;

            resultingDataStreams = dataGroups.filter(function (dataGroup) {
                var userGroups = dataGroup.userGroups || [];
                return currentUser.hasAllAuthority() || userGroups.some(function (userGroup) {
                    return currentUserGroupIds.indexOf(userGroup.id) >= 0;
                });
            });

            errorHandler.debug(
                'Based on the userGroups', responses[0],
                'and user Roles', responses[1],
                'you should have access to', resultingDataStreams
            );

            return resultingDataStreams;
        });
    }

    function loadUserGroups() {
        return Restangular.one('userGroups').withHttpConfig({cache: true}).get({
            fields: ['id', 'name'].join(','),
            filter: 'name:like:Data',
            paging: false
        }).then(function (response) {
            var userGroups = response.userGroups;

            dataGroups.forEach(function (dataGroup) {
                dataGroup.userGroups = getValuesFilteredByName(userGroups,
                    getNameFromConfig(dataGroup.name, userGroupNameConfig));
            });

            return userGroups;
        }, errorHandler.errorFn('Failed to load the usergroups'));
    }

    function loadUserRoles() {
        return Restangular.one('userRoles').withHttpConfig({cache: true}).get({
            fields: ['id', 'name'].join(','),
            filter: getRoleFilters(),
            paging: false
        }).then(function (response) {
            var userRoles = response.userRoles;

            dataGroups.forEach(function (dataGroup) {
                dataGroup.userRoles = getValuesFilteredByName(userRoles,
                    getNameFromConfig(dataGroup.name, userRoleNameConfig));
            });

            return userRoles;
        }, errorHandler.errorFn('Failed to load the userroles'));
    }

    function getValuesFilteredByName(valueArray, filterOn) {
        if (!angular.isArray(valueArray)) {
            return [];
        }

        return valueArray.filter(function (userGroup) {
            return filterOn === userGroup.name;
        });
    }

    function getRoleFilters() {
        return dataGroups.filter(function (dataGroup) {
            return dataGroup && dataGroup.name && typeof dataGroup.name === 'string';
        }).map(function (dataGroup) {
            if (dataGroup.name) {
                return getNameEqualsFilterFor(
                    getNameFromConfig(dataGroup.name, userRoleNameConfig));
            }
        });
    }

    function getNameEqualsFilterFor(name) {
        return [
            'name',
            'eq',
            name
        ].join(':');
    }

    function getNameFromConfig(name, config) {
        return [config.prefix, name, config.suffix].join(' ').trim();
    }

    function getDataGroups() {
        return deferred;
    }

    function getDataGroupsForUser(user) {
        var userGroupIds;
        var userRoleIds;
        if (!(user && user.userGroups && user.userCredentials)) {
            return $q.reject('Invalid user object provided');
        }
        userGroupIds = (user.userGroups || []).map(function (userGroup) {
            return userGroup.id;
        });
        userRoleIds = ((user.userCredentials && user.userCredentials.userRoles) || []).map(function (userRole) {
            return userRole.id;
        });

        return $q.all([loadUserGroups(), loadUserRoles()])
            .then(determineDataAccessByUserGroups(userGroupIds))
            .then(determineDataEntryByUserRoles(userRoleIds));
    }

    function determineDataAccessByUserGroups(userGroupIds) {
        return function () {
            return dataGroups.map(function (dataGroup) {
                if (hasAll(dataGroup.userGroups, userGroupIds)) {
                    dataGroup.access = true;
                } else {
                    dataGroup.access = false;
                }
                return dataGroup;
            });
        };
    }

    function determineDataEntryByUserRoles(userRoleIds) {
        return function () {
            return dataGroups.map(function (dataGroup) {
                //FIXME: Currently checks all roles to determine data entry but this could change
                //if more streams specific roles are added.
                if (hasAll(dataGroup.userRoles, userRoleIds)) {
                    dataGroup.entry = true;
                } else {
                    dataGroup.entry = false;
                }
                return dataGroup;
            });
        };
    }

    function hasAll(checkFor, against) {
        var remaining = checkFor.filter(function (userGroup) {
            if (against.indexOf(userGroup.id) >= 0) {
                return true;
            }
            return false;
        });

        return checkFor.length === remaining.length;
    }

    function getUserGroups(userToEdit, dataGroups, userStreams) {
        var userGroupIds = _.values(_.pluck(_.flatten(_.pluck(dataGroups, 'userGroups')), 'id'));
        var baseGroups = _.filter(userToEdit.userGroups, function (userGroup) {
            return userGroupIds.indexOf(userGroup.id) === -1;
        });

        dataGroups = dataGroups.map(function (dataGroup) {
            if (userStreams && userStreams[dataGroup.name] && userStreams[dataGroup.name].access) {
                dataGroup.access = true;
            }
            return dataGroup;
        });

        dataGroups = _.filter(dataGroups, function (dataGroup) {
            return (userStreams && dataGroup && userStreams[dataGroup.name] && userStreams[dataGroup.name].access === true);
        });

        var dataUserGroups = _.flatten(_.pluck(_.filter(dataGroups, function (dataGroup) {
            return dataGroup.access === true;
        }), 'userGroups'));

        return [].concat(baseGroups).concat(dataUserGroups);
    }
}
dataGroupsService.$inject = ['$q', 'Restangular', 'currentUserService', '_', 'errorHandler'];

angular.module('PEPFAR.usermanagement').controller('addUserController', addUserController);

function addUserController($scope, userTypes, dataGroups, currentUser, dimensionConstraint,
                           userActions, userService, $state, notify, interAgencyService,
                           userFormService, errorHandler) {
    var vm = this;
    var validations = userFormService.getValidations();

    vm.title = 'Add or delete user';
    vm.dataGroups = dataGroups || [];
    vm.actions = [];
    vm.languages = [];
    vm.isProcessingAddUser = false;
    vm.addUser = addUser;
    vm.validateDataGroups = validateDataGroups;
    vm.dataGroupsInteractedWith = validations.dataGroupsInteractedWith;
    vm.allowUserAdd = false;
    vm.dimensionConstraint = dimensionConstraint;
    vm.userInviteObject = {};
    vm.isRequiredDataStreamSelected = isRequiredDataStreamSelected;
    vm.updateDataEntry = updateDataEntry;
    vm.dataEntryAction = false;
    vm.isGlobalUser = currentUser.isGlobalUser && currentUser.isGlobalUser();
    vm.dataEntryStreamNamesForUserType = [];
    vm.getDataEntryStreamNamesForUserType = getDataEntryStreamNamesForUserType;

    errorHandler.debug(currentUser.isGlobalUser && currentUser.isGlobalUser() ? 'Is a global user' : 'Is not a global user');
    $scope.userOrgUnit = {
        current:  vm.activeOrgUnit = (currentUser && currentUser.organisationUnits && currentUser.organisationUnits[0]) || undefined
    };
    $scope.userTypes = userTypes || [];
    $scope.user = userService.getUserObject();

    $scope.$watch('userOrgUnit.current', function (newVal, oldVal) {
        if (newVal !== oldVal && newVal && newVal.name) {
            $scope.$broadcast('ORGUNITCHANGED', newVal);
        }
    });

    initialize();

    $scope.$watch('user.userType', function (newVal, oldVal) {
        if (newVal !== oldVal && newVal && newVal.name) {
            $scope.user.userActions = {};
            vm.actions = userActions.getActionsForUserType(newVal.name);

            if (newVal.name === 'Inter-Agency') {
                interAgencyService.getUserGroups(getCurrentOrgUnit()).then(function (interAgencyUserGroups) {
                    $scope.user.userEntity = interAgencyUserGroups;
                });
            }

            vm.dataEntryStreamNamesForUserType = vm.getDataEntryStreamNamesForUserType();
        }
    });

    function updateDataEntry() {
        var userType = getUserType();
        var userGroupsThatApplyForDataEntryForUserType = userActions.getDataEntryRestrictionDataGroups(userType);

        Object.keys($scope.user.dataGroups)
            .forEach(function (dataGroup) {
                $scope.user.dataGroups[dataGroup].entry = vm.dataEntryAction && (userGroupsThatApplyForDataEntryForUserType.indexOf(dataGroup) >= 0);
            });
    }

    function initialize() {
        if (!currentUser.hasAllAuthority() && !currentUser.isUserAdministrator()) {
            errorHandler.debug('This user is not a user administrator');
            errorHandler.debug('All authority returned: ', currentUser.hasAllAuthority());
            errorHandler.debug('User administrator role returned: ', currentUser.isUserAdministrator());
            $state.go('noaccess', {message: 'Your user account does not seem to have the authorities to access this functionality.'});
            return;
        }

        if (vm.dataGroups.length <= 0) {
            errorHandler.debug('This user does not seem to have access to any data streams');
            errorHandler.debug('User data streams', vm.dataGroups, dataGroups);
            $state.go('noaccess', {message: 'Your user account does not seem to have access to any of the data streams.'});
            return;
        }

        vm.dataGroups.reduce(function (dataGroups, dataGroup) {
            if (dataGroup && dataGroup.name) {
                dataGroups[dataGroup.name] = {
                    access: false,
                    entry: false
                };
            }
            return dataGroups;
        }, $scope.user.dataGroups);

        vm.actions = userActions.getActionsForUserType();
    }

    function getCurrentOrgUnit() {
        return ($scope.userOrgUnit && $scope.userOrgUnit.current) || {};
    }

    function addUser() {
        var managerRole = 'Manage users';

        vm.isProcessingAddUser = true;

        vm.userInviteObject = userService.getUserInviteObject(
            $scope.user,
            vm.dataGroups,
            vm.actions,
            [getCurrentOrgUnit()],
            userActions.dataEntryRestrictions
        );

        if (getUserType() !== 'Inter-Agency') {
            vm.userInviteObject.addDimensionConstraint(dimensionConstraint);
        }

        if (!userService.verifyInviteData(vm.userInviteObject)) {
            notify.error('Invite did not pass basic validation');
            return;
        }

        //Add the all mechanisms group from the user entity
        if ($scope.user.userEntity &&
            $scope.user.userEntity.mechUserGroup &&
            $scope.user.userEntity.userUserGroup &&
            $scope.user.userEntity.mechUserGroup.id &&
            $scope.user.userEntity.userUserGroup.id) {
            vm.userInviteObject.addEntityUserGroup($scope.user.userEntity.mechUserGroup);
            vm.userInviteObject.addEntityUserGroup($scope.user.userEntity.userUserGroup);
        } else {
            notify.error('User groups for mechanism and users not found on selected entity');
            return false;
        }

        //TODO: Perhaps this logic should be moved to the userService?
        if ($scope.user.userActions && $scope.user.userActions[managerRole] === true && $scope.user.userEntity.userAdminUserGroup) {
            vm.userInviteObject.addEntityUserGroup($scope.user.userEntity.userAdminUserGroup);
        }

        //TODO: Clean this up
        userService.inviteUser(vm.userInviteObject)
            .then(function (newUser) {
                if (newUser.userCredentials && angular.isString(newUser.userCredentials.code) && $scope.user.locale && $scope.user.locale.name) {
                    userService.saveUserLocale(newUser.userCredentials.code, $scope.user.locale.name)
                        .then(function () {
                            notify.success('User invitation sent');
                            $scope.user = userService.getUserObject();
                            vm.isProcessingAddUser = false;
                            $state.go('add', {}, {reload: true});
                        }, function () {
                            vm.isProcessingAddUser = false;
                            notify.warning('Saved user but was not able to save the user locale');
                        });
                }

            }, function () {
                notify.error('Request to add the user failed');
                vm.isProcessingAddUser = false;
            });
    }

    function validateDataGroups() {
        return validations.validateDataGroups($scope.user.dataGroups);
    }

    function isRequiredDataStreamSelected(dataGroupNames) {
        return validations.isRequiredDataStreamSelected(dataGroupNames, $scope.user, vm.dataGroups);
    }

    function getDataEntryStreamNamesForUserType() {
        return userActions.getDataEntryRestrictionDataGroups(getUserType());
    }

    function getUserType() {
        return $scope.user && $scope.user.userType && $scope.user.userType.name;
    }
}
addUserController.$inject = ['$scope', 'userTypes', 'dataGroups', 'currentUser', 'dimensionConstraint', 'userActions', 'userService', '$state', 'notify', 'interAgencyService', 'userFormService', 'errorHandler'];

angular.module('PEPFAR.usermanagement').controller('userListController', userListController);

function userListController(userFilter, currentUser, userTypesService, dataGroupsService, userListService,  //jshint ignore:line
                            userStatusService, $state, $scope, errorHandler, userActions) {
    var vm = this;

    vm.detailsOpen = false;
    vm.users = [];
    vm.pagination = userListService.pagination;
    vm.processing = {};
    vm.listIsLoading = false;
    vm.currentPage = 1;
    vm.pageChanged = pageChanged;
    vm.activateUser = activateUser;
    vm.deactivateUser = deactivateUser;
    vm.isProcessing = isProcessing;
    vm.showDetails = showDetails;
    vm.detailsUser = undefined;
    vm.isDetailsUser = isDetailsUser;
    vm.getDataGroupsForUser = getDataGroupsForUser;
    vm.detailsUserDataGroups = [];
    vm.detailsUserUserType = '';
    vm.detailsUserActions = [];
    vm.doSearch = doSearch;
    vm.editUser = editUser;
    vm.placeHolder = 'Search for user';
    vm.updatePlaceholder = updatePlaceholder;
    vm.checkDownload = checkDownload;
    vm.closeDetails = closeDetails;
    vm.removeFilter = removeFilter;
    vm.addFilter = addFilter;
    vm.resetFilters = resetFilters;

    vm.search = {
        options: userFilter,
        filterType: undefined,
        searchWord: '',
        doSearch: _.debounce(vm.doSearch, 500),
        fileCreated: false,
        fileDownload: {
            url: '',
            download: ''
        },
        getFilters: getFilters,
        activeFilters: [],
        addFilter: addFilter,
        placeHolderText: [],
        hasSecondaryFilter: hasSecondaryFilter,
        getSecondaryFilter: getSecondaryFilter

    };

    initialise();

    function initialise() {
        if (!currentUser.hasAllAuthority() && !currentUser.isUserAdministrator()) {
            return $state.go('noaccess', {message: 'Your user account does not seem to have the authorities to access this functionality.'});
        }

        loadList();
    }

    function hasSecondaryFilter(filterIndex) {
        return (vm.search.activeFilters[filterIndex] && vm.search.activeFilters[filterIndex].type && vm.search.activeFilters[filterIndex].type.secondary);
    }

    function getSecondaryFilter(filterIndex) {
        if (hasSecondaryFilter(filterIndex)) {
            return vm.search.activeFilters[filterIndex].type.secondary;
        }
    }

    function setUserList(users) {
        vm.listIsLoading = false;
        vm.users = users;
    }

    function pageChanged() {
        vm.pagination.setCurrentPage(vm.currentPage);
        loadList();
    }

    function loadList() {
        vm.listIsLoading = true;
        userListService.getList()
            .then(setUserList)
            .then(buildCSV)
            .catch(function () {
                vm.listIsLoading = false;
            });
    }

    function activateUser(user) {
        vm.processing[user.id] = true;

        userStatusService.enable(user.id)
            .then(function () {
                user.userCredentials.disabled = false;
                vm.processing[user.id] = false;
            })
            .catch(function () {
                vm.processing[user.id] = false;
                errorHandler.error('Unable to enable the user');
            });
    }

    function deactivateUser(user) {
        vm.processing[user.id] = true;

        userStatusService.disable(user.id)
            .then(function () {
                user.userCredentials.disabled = true;
                vm.processing[user.id] = false;
            })
            .catch(function () {
                vm.processing[user.id] = false;
                errorHandler.error('Unable to disable the user');
            });
    }

    function isProcessing(id) {
        return (vm.processing[id] && vm.processing[id] === true) ? true : false;
    }

    //TODO: Move the jQuery stuff out of the controller as it's considered bad practice.
    //      Very nice solution provided by Paul but we should move it into a directive.
    //TODO: Perhaps it would also be nice to never have it be out of sight if it is available?
    var detailsBlock = jQuery('.user-details-view');
    function showDetails(user) {
        var detailsRow = jQuery('.user-list li[user-id=' + user.id + ']');
        var detailsWrap = detailsRow.parent();
        var parentHeight = detailsWrap.innerHeight();
        var position = detailsRow.position() || {};
        var detailsBlockHeight = detailsBlock.innerHeight() || 400; //TODO: Remove this static 400 in favour of some jQuery actual height calculation

        if (detailsBlockHeight + position.top >= parentHeight) {
            position.top = parentHeight - detailsBlockHeight;
        }

        if (!vm.detailsOpen) {
            detailsBlock.offset({top: position.top, right: 0}); //jshint ignore:line
        } else {
            detailsBlock.css('top', position.top); //jshint ignore:line
        }

        if (user !== vm.detailsUser) {
            vm.detailsUser = user;
            vm.detailsOpen = true;
            vm.getDataGroupsForUser(user);
            vm.detailsUserUserType = userTypesService.getUserType(user);
            userActions.getActionsForUser(user).then(function (actions) {
                vm.detailsUserActions = actions;
            });

        } else {
            closeDetails();
        }
    }

    function closeDetails() {
        vm.detailsUser = undefined;
        vm.detailsOpen = false;
    }

    function isDetailsUser(user) {
        return user === vm.detailsUser;
    }

    function getDataGroupsForUser(user) {
        dataGroupsService.getDataGroupsForUser(user)
            .then(function (dataGroups) {
                vm.detailsUserDataGroups = dataGroups;
            })
            .catch(function () {
                errorHandler.warning('Failed to load datagroups for user');
            });
    }

    function updatePlaceholder($index) {
        var newVal = vm.search.filterType[$index];
        var phText = 'Search for ';
        var outputStr = '';

        if (newVal.name === 'E-Mail' || newVal.name === 'Roles') {
            outputStr = phText + 'user ';
        } else {
            outputStr = phText;
        }

        window.console.log(vm.search.placeHolderText[$index]);
        vm.search.placeHolderText[$index] = outputStr + newVal.name;

    }

    //TODO: Move the search stuff to the filter service
    function doSearch() {
        var fieldNames = {
            name: 'name',
            username: 'userCredentials.code',
            'e-mail': 'email',
            roles: 'userCredentials.userRoles.name',
            'user groups': 'userGroups.name',
            'organisation unit': 'organisationUnits.name',
            types: 'userGroups.name'
        };
        resetFileDownload();

        userListService.resetFilters();

        vm.search.activeFilters.forEach(function (filterDefinition) {
            var filter;

            //Only use valid filters
            if (!isValidFilter(filterDefinition)) { return; }

            filter = [
                fieldNames[filterDefinition.type.name.toLowerCase()],
                filterDefinition.comparator,
                angular.isString(filterDefinition.value) ? filterDefinition.value : filterDefinition.value.name
            ];

            userListService.setFilter(filter.join(':'));
        });

        loadList();
    }

    function isValidFilter(filterDefinition) {
        return filterDefinition &&
            filterDefinition.type &&
            filterDefinition.type.name &&
            filterDefinition.comparator &&
            filterDefinition.value;
    }

    function removeFilter($index) {
        vm.search.activeFilters.splice($index, 1);
        userListService.removeFilter($index);
        doSearch();
    }

    function addFilter() {
        if (vm.search.activeFilters.length < 5) {
            vm.search.activeFilters.push({
                id: new Date().toString(),
                type: undefined,
                value: undefined,
                comparator: 'like'
            });
        }
    }

    function resetFilters() {
        vm.search.activeFilters = [];
        userListService.resetFilters();
        doSearch();
    }

    function editUser(user) {
        if (user && user.id && user.userCredentials && user.userCredentials.code) {
            $state.go('edit', {userId: user.id, username: user.userCredentials.code});
        }
    }

    function getFilters() {
        vm.search.filters = userListService.getFilters();
    }

    //TODO: Refactor to factory if CSV functionality is needed elsewhere
    function checkDownload() {
        return !window.externalHost && 'download' in document.createElement('a'); //jshint ignore:line
    }

    function resetFileDownload() {
        vm.search.fileCreated = false;
    }

    function buildCSV() {
        var header = 'Name, Email, Last Login, Access Level, Groups\n';
        var localUsers = vm.users;
        var finalCSV = [];

        if (!vm.checkDownload()) {
            return;
        }

        try {
            for (var i = 0, len = localUsers.length; i < len; i = i + 1) {
                finalCSV.push(buildRow(localUsers[i]));
            }

            vm.search.fileDownload.url = 'data:text/csv;base64,' + window.btoa(
                header + finalCSV.join('\n')
            );

        } catch (e) {
            window.console.error(e);
        }

        vm.search.fileDownload.download = getFileName();
        vm.search.fileCreated = true;

    }

    function buildRow(row) {
        var tempObj = [];

        tempObj.push(row.name);
        tempObj.push(row.email || '');
        tempObj.push(buildList(row.userCredentials.userRoles) || '');
        tempObj.push(row.userCredentials.userRoles[0].lastUpdated);
        tempObj.push(buildList(row.userGroups) || '');
        tempObj.push(buildList(row.organisationUnits) || '');

        return tempObj.join(',');
    }

    function getFileName() {
        var res = new Date().toISOString();
        var fileName = [];

        fileName.push(res.substring(0, 16).replace(/:/g, ''));
        fileName.push(currentUser.name);

        window.console.log(res.substring(0, 16));

        return fileName.join('-') + '-Page1.csv';
    }

    function buildList(listArr) {
        var arr = [];

        for (var i = 0, len = listArr.length; i < len; i = i + 1) {
            arr.push('"' + listArr[i].name + '"');
        }

        return '"' + arr.join(',') + '"';
    }
}
userListController.$inject = ['userFilter', 'currentUser', 'userTypesService', 'dataGroupsService', 'userListService', 'userStatusService', '$state', '$scope', 'errorHandler', 'userActions'];

angular.module('PEPFAR.usermanagement').service('userFilterService', userFilterService);

function userFilterService($q, userTypesService, organisationUnitService) {
    var deferred = $q.defer();
    var userFilter = [
        {name: 'Name'},
        {name: 'Username'},
        {name: 'E-Mail'},
        {name: 'Roles'},
        {name: 'User Groups'}
    ];

    deferred.resolve(userFilter);

    initialise();
    return {
        getUserFilter: getUserFilter
    };

    function initialise() {
        organisationUnitService.getOrganisationUnitsForLevel(3)
            .then(function (organisationUnits) {
                userFilter.push({name: 'Organisation Unit', secondary: organisationUnits});
            });

        userTypesService.getUserTypes()
            .then(function (userTypes) {
                userFilter.push({name: 'Types', secondary: userTypes});
            });
    }

    function getUserFilter() {
        return deferred.promise;
    }
}
userFilterService.$inject = ['$q', 'userTypesService', 'organisationUnitService'];

angular.module('PEPFAR.usermanagement').factory('paginationService', paginationService);

function paginationService() {
    var currentPage = 1;
    var totalItemCount = 0;
    var numberOfPages = 0;
    var defaultPageSize = 25;

    return {
        getCurrentPage: getCurrentPage,
        setCurrentPage: setCurrentPage,
        setPagination: setPagination,
        getTotalItemCount: getTotalItemCount,
        getNumberOfPages: getNumberOfPages,
        getNextPageNumber: getNextPageNumber,
        getPreviousPageNumber: getPreviousPageNumber,
        getPageSize: getPageSize
    };

    function getCurrentPage() {
        return currentPage;
    }

    function setCurrentPage(newCurrentPage) {
        if (angular.isNumber(newCurrentPage) && newCurrentPage > 0 && newCurrentPage <= getNumberOfPages()) {
            currentPage = newCurrentPage;
        }
    }

    function setPagination(paginateOptions) {
        currentPage = paginateOptions.page || 1;
        totalItemCount = paginateOptions.total || 0;
        numberOfPages = paginateOptions.pageCount || 0;
    }

    function getTotalItemCount() {
        return totalItemCount;
    }

    function getNumberOfPages() {
        return numberOfPages;
    }

    function getNextPageNumber() {
        if ((getCurrentPage() + 1) < numberOfPages) {
            return getCurrentPage() + 1;
        } else {
            return numberOfPages;
        }
    }

    function getPreviousPageNumber() {
        if ((getCurrentPage() - 1) > 0) {
            return getCurrentPage() - 1;
        } else {
            return 1;
        }
    }

    function getPageSize() {
        return defaultPageSize;
    }
}

angular.module('PEPFAR.usermanagement').factory('userListService', userListService);

function userListService(Restangular, paginationService, errorHandler) {
    var fields = ['id', 'name', 'email', 'organisationUnits', 'userCredentials[code,disabled,userRoles]', 'userGroups'];
    var filters = [];

    return {
        getList: getList,
        pagination: paginationService,
        setFilter: setFilter,
        getFilters: getFilters,
        resetFilters: resetFilters,
        removeFilter: removeFilter,
        filters: filters
    };

    function getList() {
        return Restangular.one('users')
            .get(getRequestParams())
            .then(setPagination)
            .then(extractUsers)
            .catch(errorHandler.errorFn('Unable to get the list of users from the server'));
    }

    function setPagination(response) {
        if (response.pager) {
            paginationService.setPagination(response.pager);
        }
        return response;
    }

    function extractUsers(response) {
        return response.users || [];
    }

    function getRequestParams() {
        cleanFilters();
        return {
            fields: fields.join(','),
            page: paginationService.getCurrentPage(),
            pageSize: paginationService.getPageSize(),
            filter: filters,
            manage: 'true'
        };
    }

    function getFilters() {
        //window.console.log('ListService: Getting the filters' + filters);
        return filters;
    }

    function setFilter(filter) {
        //window.console.log('ListService: pushing filter: "' + filter + '" length ' + filter.length);
        filters.push(filter);
    }

    function resetFilters() {
        filters = [];
    }

    function removeFilter(index) {
        filters.splice(index, 1);
    }

    function cleanFilters() {
        var arr = [];
        for (var i = 0, len = filters.length; i < len; i = i + 1) {
            if (filters[i].length > 0) {
                arr.push(filters[i]);
            }
        }
        filters = arr;
    }
}
userListService.$inject = ['Restangular', 'paginationService', 'errorHandler'];

angular.module('PEPFAR.usermanagement').directive('agencySelect', agencySelectDirective);

function agencySelectDirective(agenciesService, $translate, errorHandler) {
    return {
        restrict: 'E',
        replace: true,
        scope: true,
        templateUrl: 'pepfar/agencypartner-select.html',
        link: function (scope) {
            scope.selectbox = {
                items: [],
                placeholder: $translate.instant('Select an agency')
            };

            loadValues(scope.userOrgUnit && scope.userOrgUnit.current);

            scope.$on('ORGUNITCHANGED', function (event, data) {
                errorHandler.debug('Reloading types for ', data.name);
                loadValues(data);
            });

            function loadValues(orgUnit) {
                orgUnit = orgUnit || {};

                errorHandler.debug('Loading agencies for: ', orgUnit.name);
                agenciesService.getAgencies(orgUnit).then(function (agencies) {
                    scope.selectbox.items = agencies;
                });
            }
        }
    };
}
agencySelectDirective.$inject = ['agenciesService', '$translate', 'errorHandler'];

angular.module('PEPFAR.usermanagement').factory('agenciesService', agenciesService);

function agenciesService($q, Restangular, errorHandler) {

    return {
        getAgencies: getAgencies
    };

    function getAgencies(organisationUnit) {
        return getAgenciesForOrganisationUnit(organisationUnit);
    }

    function getAgenciesForOrganisationUnit(organisationUnit) {
        var organisationUnitName;

        if (!(organisationUnit && organisationUnit.name)) {
            return $q.reject('No organisation unit found');
        }
        organisationUnitName = organisationUnit.name;

        return matchUserGroupsWithAgencies(organisationUnitName).catch(errorHandler.debug);
    }

    function matchUserGroupsWithAgencies(organisationUnitName) {
        return $q.all([
                getFundingAgencyCogs().then(getAgencyObjects),
                getUserGroups(organisationUnitName)
            ])
            .then(function (responses) {
                var agencyDimensionResponse = Array.isArray(responses[0]) ? responses[0] : [];
                var userGroups = Array.isArray(responses[1]) ? responses[1] : [];
                var agencies = matchAgenciesWithUserGroups(agencyDimensionResponse, userGroups, organisationUnitName);

                if (agencies && agencies.length > 0) {
                    errorHandler.debug(
                        errorHandler.message(['Found', agencies.length, 'agencies for which you can also access the required user groups.']),
                        agencies
                    );

                    return agencies;
                }

                return $q.reject(['No agencies found in', organisationUnitName, 'that you can access all mechanisms for'].join(' '));
            });
    }

    function getAgencyObjects(cogsId) {
        var queryParams = {
            fields: 'categoryOptionGroups',
            paging: 'false'
        };

        //categoryOptionGroupSets.json?fields=id&filter=name:eq:Funding%20Agency&paging=false
        return Restangular
            .all('categoryOptionGroupSets').withHttpConfig({cache: true})
            .get(cogsId, queryParams)
            .then(function (response) {
                errorHandler.debug(errorHandler.message(['Found', (response.categoryOptionGroups && response.categoryOptionGroups.length) || 0, 'agencies that you can access']));

                return response.categoryOptionGroups;
            })
            .then(function (agencies) {
                var agenciesWithCodes = (agencies || []).filter(function (agency) {
                    return (agency && angular.isString(agency.code) && agency.code !== '');
                });

                errorHandler.debug(errorHandler.message(['Of the accessible agencies', agenciesWithCodes.length, 'has/have a code']), agenciesWithCodes);

                return agenciesWithCodes;
            });
    }

    function getFundingAgencyCogs() {
        return Restangular
            .one('categoryOptionGroupSets').withHttpConfig({cache: true})
            .get({
                fields: 'id',
                filter: 'name:eq:Funding Agency',
                paging: false
            })
            .then(function (response) {
                var categoryOptionGroupSets = response.categoryOptionGroupSets || [];

                if (categoryOptionGroupSets.length !== 1) {
                    return $q.reject('None or more than one categoryOptionGroupSets found that match "Funding Agency"');
                }

                return categoryOptionGroupSets[0].id;
            });
    }

    function getUserGroups(organisationUnitName) {
        var queryParams;

        queryParams = {
            fields: 'id,name',
            filter: [
                ['name', 'like', [organisationUnitName.trim(), 'Agency'].join(' ')].join(':')
            ],
            paging: false
        };

        return Restangular.one('userGroups').withHttpConfig({cache: true})
            .get(queryParams)
            .then(function (userGroups) {

                errorHandler.debug(
                    errorHandler.message(['Found ', userGroups.userGroups.length, 'usergroups whos name contains', '"', [organisationUnitName.trim(), 'Agency'].join(' '), '"']),
                    userGroups.userGroups
                );

                return userGroups.userGroups;
            });
    }

    function matchAgenciesWithUserGroups(agencies, userGroups, organisationUnitName) {
        return agencies.map(addUserGroups(userGroups, organisationUnitName))
            .filter(agencyWithMechanismsAndUserUserGroups);
    }

    function agencyWithMechanismsAndUserUserGroups(agency) {
        return angular.isObject(agency.mechUserGroup) && agency.mechUserGroup !== null &&
            angular.isObject(agency.userUserGroup) && agency.userUserGroup;
    }

    function addUserGroups(userGroups, organisationUnitName) {
        var mechUserGroupRegex;
        var userUserGroupRegex;
        var userAdminUserGroupRegex;

        return function (agency) {
            mechUserGroupRegex = userGroupRegExp(organisationUnitName, agency, 'all mechanisms');
            userUserGroupRegex = userGroupRegExp(organisationUnitName, agency, 'users');
            userAdminUserGroupRegex = userGroupRegExp(organisationUnitName, agency, 'user administrators');

            userGroups.reduce(function (current, userGroup) {
                if (mechUserGroupRegex.test(userGroup.name)) {
                    agency.mechUserGroup = userGroup;
                    return agency;
                }
                if (userUserGroupRegex.test(userGroup.name)) {
                    agency.userUserGroup = userGroup;
                    return agency;
                }
                if (userAdminUserGroupRegex.test(userGroup.name)) {
                    agency.userAdminUserGroup =  userGroup;
                    return agency;
                }
                return agency;
            }, agency);

            return agency;
        };
    }

    function userGroupRegExp(organisationUnitName, agency, suffix) {
        return new RegExp(['^OU', organisationUnitName, underscoreToSpace(agency.code), [suffix, '$'].join('')].join(' '));
    }

    function underscoreToSpace(code) {
        var agencyCodeRegExp = new RegExp('^Agency_', '');

        return (code || '').replace(agencyCodeRegExp, 'Agency ');
    }
}
agenciesService.$inject = ['$q', 'Restangular', 'errorHandler'];

angular.module('PEPFAR.usermanagement').directive('partnerSelect', partnerSelectDirective);

function partnerSelectDirective(partnersService, $translate, errorHandler) {
    return {
        restrict: 'E',
        replace: true,
        scope: true,
        templateUrl: 'pepfar/agencypartner-select.html',
        link: function (scope) {
            scope.selectbox = {
                items: [],
                placeholder: $translate.instant('Select a partner')
            };

            loadValues(scope.userOrgUnit && scope.userOrgUnit.current);

            scope.$on('ORGUNITCHANGED', function (event, data) {
                errorHandler.debug('Reloading types for ', data.name); //jshint ignore:line
                loadValues(data);
            });

            function loadValues(orgUnit) {
                orgUnit = orgUnit || {};

                errorHandler.debug('Loading partners for: ', orgUnit.name);
                partnersService.getPartners(orgUnit).then(function (partners) {
                    scope.selectbox.items = partners;
                });
            }
        }
    };
}
partnerSelectDirective.$inject = ['partnersService', '$translate', 'errorHandler'];

angular.module('PEPFAR.usermanagement').factory('partnersService', partnersService);

function partnersService($q, Restangular, errorHandler) {

    return {
        getPartners: getPartners
    };

    function getPartners(organisationUnit) {
        return getPartnersForOrganisationUnit(organisationUnit);
    }

    function getPartnersForOrganisationUnit(organisationUnit) {
        var organisationUnitName;

        if (!(organisationUnit && organisationUnit.name)) {
            return $q.reject('No organisation unit found');
        }
        organisationUnitName = organisationUnit.name;

        return $q.all([
                getImplementingPartnerCogs().then(getPartnersFromApi),
                getUserGroups(organisationUnitName)]
            )
            .then(matchPartnersWithUserGroups)
            .catch(errorHandler.debugFn(['No partners found in', organisationUnitName, 'that you can access all mechanisms for'].join(' ')));
    }

    function matchPartnersWithUserGroups(responses) {
        var partners = responses[0] || [];
        var userGroups = responses[1] || [];

        partners = partners
            .map(addUserGroupsToPartners(userGroups))
            .filter(partnersWithUserGroupId);

        if (partners && partners.length > 0) {
            errorHandler.debug(
                errorHandler.message(['Found', partners.length, 'partners for which you can also access the required user groups.']),
                partners
            );

            return partners;
        }
        return $q.reject('No partners found matching given userGroups and partners');
    }

    function addUserGroupsToPartners(userGroups) {
        return function (partner) {
            var partnerMechRegExp = userGroupRegExp(partner, 'all mechanisms');
            var partnerUserRegExp = userGroupRegExp(partner, 'users');
            var userAdminUserGroup = userGroupRegExp(partner, 'user administrators');

            userGroups.forEach(function (userGroup) {
                if (partnerMechRegExp.test(userGroup.name)) {
                    partner.mechUserGroup = userGroup;
                }

                if (partnerUserRegExp.test(userGroup.name)) {
                    partner.userUserGroup = userGroup;
                }

                if (userAdminUserGroup.test(userGroup.name)) {
                    partner.userAdminUserGroup = userGroup;
                }
            });

            return partner;
        };
    }

    function userGroupRegExp(partner, userGroupType) {
        return new RegExp(['^OU .+?', underscoreToSpace(partner.code), userGroupType, '- .+$'].join(' '), 'i');
    }

    function underscoreToSpace(code) {
        var partnerCodeRegExp = new RegExp('^Partner_', '');

        return (code || '').replace(partnerCodeRegExp, 'Partner ');
    }

    function partnersWithUserGroupId(partner) {
        return partner.mechUserGroup && partner.mechUserGroup.id &&
            partner.userUserGroup && partner.userUserGroup.id;
    }

    function getPartnersFromApi(cogsId) {
        var queryParams = {
            fields: 'categoryOptionGroups',
            paging: 'false'
        };

        return Restangular
            .all('categoryOptionGroupSets').withHttpConfig({cache: true})
            .get(cogsId, queryParams)
            .then(function (response) {
                errorHandler.debug(
                    errorHandler.message(['Found', (response.categoryOptionGroups && response.categoryOptionGroups.length) || 0, 'partners that you can access'])
                );

                return response.categoryOptionGroups;
            })
            .then(function (partners) {
                var partnersWithCode = (partners || []).filter(function (partner) {
                    return (partner && angular.isString(partner.code) && partner.code !== '');
                });

                errorHandler.debug(errorHandler.message(['Of the accessible partners', partnersWithCode.length, 'has/have a code']), partnersWithCode);

                return partnersWithCode;
            });
    }

    function getImplementingPartnerCogs() {
        return Restangular
            .one('categoryOptionGroupSets').withHttpConfig({cache: true})
            .get({
                fields: 'id',
                filter: 'name:eq:Implementing Partner',
                paging: false
            })
            .then(function (response) {
                var categoryOptionGroupSets = response.categoryOptionGroupSets || [];

                if (categoryOptionGroupSets.length !== 1) {
                    return $q.reject('None or more than one categoryOptionGroupSets found that match "Implementing Partner"');
                }
                return categoryOptionGroupSets[0].id;
            });
    }

    function getUserGroups(organisationUnitName) {
        var queryParams = {
            fields: 'id,name',
            filter: [
                ['name', 'like', [organisationUnitName, 'partner'].join(' ')].join(':')
            ],
            paging: false
        };

        return Restangular
            .one('userGroups').withHttpConfig({cache: true})
            .get(queryParams)
            .then(function (userGroups) {

                errorHandler.debug(
                    errorHandler.message(['Found ', userGroups.userGroups.length, 'usergroups whos name contains', '"', [organisationUnitName.trim(), 'Partner'].join(' '), '"']),
                    userGroups.userGroups
                );

                return userGroups.userGroups || [];
            });
    }
}
partnersService.$inject = ['$q', 'Restangular', 'errorHandler'];

angular.module('PEPFAR.usermanagement').factory('localeService', localeService);

function localeService(Restangular) {
    var localeResource = Restangular
        .all('locales')
        .all('ui')
        .getList();

    return {
        getUiLocales: getUiLocales
    };

    function getUiLocales() {
        return localeResource;
    }
}
localeService.$inject = ['Restangular'];

angular.module('PEPFAR.usermanagement').directive('localeSelect', localeSelectDirective);

function localeSelectDirective(localeService, $translate, _) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            required: '@',
            user: '='
        },
        templateUrl: 'language/locale-select.html',
        link: linkFn
    };

    function linkFn(scope) {
        scope.selectbox = {
            placeholder: $translate.instant('Select a locale')
        };

        localeService.getUiLocales().then(function (uiLocales) {
            scope.selectbox.items = _.map(uiLocales, function (uiLocale) {
                return {
                    name: uiLocale,
                    code: uiLocale
                };
            });
        });
    }
}
localeSelectDirective.$inject = ['localeService', '$translate', '_'];

angular.module('PEPFAR.usermanagement').controller('userTypeController', userTypeController);

function userTypeController($scope) {
    var vm = this;

    //Scope inherited properties
    vm.userTypes = $scope.userTypes;
    vm.user = $scope.user;

    vm.isAgency = isAgency;
    vm.isPartner = isPartner;

    //Reset the userEntity when the userType is changed
    $scope.$watch(function () {
        return $scope.user.userType;
    }, function (newVal) {
        if (newVal) {
            $scope.user.userEntity = undefined;
        }
    });

    function isAgency() {
        return isUserType('Agency');
    }

    function isPartner() {
        return isUserType('Partner');
    }

    function isUserType(userType) {
        if (!angular.isString(userType)) { return false; }

        if ($scope.user && $scope.user.userType && $scope.user.userType.name === userType) {
            return true;
        }
        return false;
    }
}
userTypeController.$inject = ['$scope'];

angular.module('PEPFAR.usermanagement').controller('editUserController', editUserController);

function editUserController($scope, $state, currentUser, dataGroups, dataGroupsService, userToEdit, //jshint maxstatements: 36
                            userLocale, userFormService, userActions,
                            notify, userService, userTypesService, errorHandler) {
    var vm = this;
    var validations = userFormService.getValidations();

    vm.userToEdit = {};
    vm.user = {
        locale: undefined,
        dataGroups: {},
        userActions: {}
    };
    vm.actions = [];
    vm.dataGroups = dataGroups || [];
    vm.validateDataGroups = validateDataGroups;
    vm.dataGroupsInteractedWith = validations.dataGroupsInteractedWith;
    vm.isRequiredDataStreamSelected = isRequiredDataStreamSelected;
    vm.editUser = editUser;
    vm.isProcessingEditUser = false;
    vm.getUserType = getUserType;
    vm.changeUserStatus = changeUserStatus;
    vm.updateDataEntry = updateDataEntry;
    vm.dataEntryStreamNamesForUserType = [];

    $scope.user = vm.user;

    initialise();
    debugWatch();

    function initialise() {
        if (!currentUser.hasAllAuthority() && !currentUser.isUserAdministrator()) {
            $state.go('noaccess', {message: 'Your user account does not seem to have the authorities to access this functionality.'});
            return;
        }

        vm.userToEdit = userToEdit;
        vm.user.locale = userLocale;

        vm.dataEntryStreamNamesForUserType = getDataEntryStreamNamesForUserType();

        dataGroupsService.getDataGroupsForUser(userToEdit)
            .then(correctUserRolesForType)
            .then(createDataGroupsObject)
            .then(setDataEntryModelValue);

        userActions.getActionsForUser(userToEdit)
            .then(setUserActionsForThisUser);
    }

    function correctUserRolesForType(response) {
        ((Array.isArray(vm.dataGroups) && vm.dataGroups) || []).forEach(function (dataGroup) {
            var userRoles = userActions.dataEntryRestrictions && userActions.dataEntryRestrictions[getUserType()] && userActions.dataEntryRestrictions[getUserType()][dataGroup.name];
            dataGroup.userRoles = (userRoles || []).filter(function (userRole) {
                return userRole.userRole && userRole.userRoleId && userRole.userRoleId !== '';
            }).map(function (userRole) {
                return {
                    id: userRole.userRoleId,
                    name: userRole.userRole
                };
            });
            return dataGroup;
        });

        return response;
    }

    function createDataGroupsObject(dataGroups) {
        dataGroups.reduce(function (dataGroups, dataGroup) {
            if (dataGroup && dataGroup.name) {
                dataGroups[dataGroup.name] = {
                    access: dataGroup.access,
                    entry: dataGroup.entry
                };
            }
            return dataGroups;
        }, $scope.user.dataGroups);
    }

    function setUserActionsForThisUser(actions) {
        vm.actions = actions;

        vm.actions.map(function (action) {
            if (action.hasAction === true) {
                vm.user.userActions[action.name] = true;
            }
        });
    }

    function setDataEntryModelValue() {
        vm.dataEntryAction = Object.keys($scope.user.dataGroups).reduce(function (dataEntryStatus, dataGroup) {
            return dataEntryStatus || $scope.user.dataGroups[dataGroup].entry;
        }, false);
    }

    //TODO: This is partial duplicate code with the add controller and should be refactored
    function updateDataEntry() {
        var userType = getUserType(userToEdit);
        var userGroupsThatApplyForDataEntryForUserType = userActions.getDataEntryRestrictionDataGroups(userType);

        if (vm.dataEntryAction === true) {
            Object.keys($scope.user.dataGroups)
                .forEach(function (dataGroup) {
                    $scope.user.dataGroups[dataGroup].entry = userGroupsThatApplyForDataEntryForUserType.indexOf(dataGroup) >= 0;
                });
        } else {
            Object.keys($scope.user.dataGroups)
                .forEach(function (dataGroup) {
                    $scope.user.dataGroups[dataGroup].entry = false;
                });
        }
    }

    function validateDataGroups() {
        return validations.validateDataGroups($scope.user.dataGroups);
    }

    function isRequiredDataStreamSelected(dataGroupNames) {
        return validations.isRequiredDataStreamSelected(dataGroupNames, $scope.user, vm.dataGroups);
    }

    function editUser() {
        var userGroups = dataGroupsService.getUserGroups(vm.userToEdit, vm.dataGroups, vm.user.dataGroups);
        userToEdit.userCredentials.userRoles = userActions.combineSelectedUserRolesWithExisting(vm.userToEdit, vm.user, vm.dataGroups, vm.actions);

        setProcessingTo(true);

        userService.updateUser(userToEdit, userGroups)
            .then(function () {
                if ($scope.user.locale && $scope.user.locale.name) {
                    saveUserLocale()
                        .then(notifyUserOfSuccessfullSave)
                        .catch(notifyUserOfFailedLocaleSave);
                } else {
                    notifyUserOfSuccessfullSave();
                }
            })
            .catch(errorHandler.errorFn('Failed to save user'))
            .finally(setProcessingToFalse);
    }

    function notifyUserOfSuccessfullSave() {
        return notify.success('User updated');
    }

    function notifyUserOfFailedLocaleSave() {
        return notify.warning('Updated user but failed to save the ui locale');
    }

    function setProcessingTo(isProcessing) {
        vm.isProcessingEditUser = isProcessing;
    }

    function setProcessingToFalse() {
        return setProcessingTo(false);
    }

    function saveUserLocale() {
        return userService.saveUserLocale(userToEdit.userCredentials.code, $scope.user.locale.name);
    }

    function getUserType() {
        return userTypesService.getUserType(userToEdit);
    }

    function getDataEntryStreamNamesForUserType() {
        return userActions.getDataEntryRestrictionDataGroups(getUserType());
    }

    function changeUserStatus() {
        if (vm.userToEdit && vm.userToEdit.userCredentials) {
            vm.userToEdit.userCredentials.disabled = vm.userToEdit.userCredentials.disabled ? false : true;
        }
    }

    function debugWatch() {
        $scope.$watch('user.locale', logUserLocaleChange);

        $scope.$watch('user.dataGroups', function (newVal, oldVal) {
            if (newVal !== oldVal)  {
                Object.keys(newVal || {}).map(function (key) {
                    if (!(oldVal[key] && oldVal[key].access === newVal[key].access)) {
                        if (newVal[key].access === true) {
                            errorHandler.debug([key, 'added.'].join(' '));
                        } else {
                            errorHandler.debug([key, 'removed.'].join(' '));
                        }
                    }
                });
            }
        }, true);

        $scope.$watch('user.userActions', function (newVal, oldVal) {
            if (newVal !== oldVal)  {
                Object.keys(newVal || {}).map(function (key) {
                    if (!(oldVal[key] && oldVal[key] === newVal[key])) {
                        if (newVal[key] === true) {
                            errorHandler.debug([key, 'added.'].join(' '));
                        } else {
                            errorHandler.debug([key, 'removed.'].join(' '));
                        }
                    }
                });
            }
        }, true);

        function logUserLocaleChange(newVal, oldVal) {
            if (newVal !== oldVal)  {
                errorHandler.debug('Changed locale from:', oldVal, ' to ', newVal); //jshint ignore:line
            }
        }
    }
}
editUserController.$inject = ['$scope', '$state', 'currentUser', 'dataGroups', 'dataGroupsService', 'userToEdit', 'userLocale', 'userFormService', 'userActions', 'notify', 'userService', 'userTypesService', 'errorHandler'];

angular.module('PEPFAR.usermanagement').factory('userService', userService);

function userService($q, Restangular, _, partnersService, agenciesService, interAgencyService) {
    var userInviteObjectStructure = {
        email:'',
        organisationUnits:[
            //{'id':'ybg3MO3hcf4'}
        ],
        dataViewOrganisationUnits:[
            //{'id':'ybg3MO3hcf4'}
        ],
        userGroups: [
            //{'id':'iuD8wUFz95X'},
            //{'id':'gh9tn4QBbKZ'}
        ],
        userCredentials:{
            userRoles:[
                //{'id':'b2uHwX9YLhu'}
            ]
        }
    };

    return {
        getUserObject: getUserObject,
        getUserInviteObject: getUserInviteObject,
        inviteUser: inviteUser,
        verifyInviteData: verifyInviteData,
        saveUserLocale: saveUserLocale,
        getSelectedDataGroups: getSelectedDataGroups,
        getUser: getUser,
        getUserEntity: getUserEntity,
        getUserLocale: getUserLocale,
        updateUser: updateUser
    };

    function getUserObject() {
        return angular.copy({
            userType: undefined,
            userEntity: undefined,
            email: undefined,
            locale: {name: 'en'},
            userActions: {},
            userGroups: [],
            userRoles: [],
            dataGroups: {}
        });
    }

    function getInviteObject() {
        var inviteObject = Object.create(getUserInviteProto());
        return angular.extend(inviteObject, angular.copy(userInviteObjectStructure));
    }

    function getUserInviteProto() {
        return {
            addDimensionConstraint: addDimensionConstraint,
            addEmail: addEmail,
            addEntityUserGroup: addEntityUserGroup
        };

        function addDimensionConstraint(dimension) {
            if (!this.userCredentials.catDimensionConstraints) {
                this.userCredentials.catDimensionConstraints = [];
            }
            if (dimension && dimension.id) {
                this.userCredentials.catDimensionConstraints.push({id: dimension.id});
            }

        }

        function addEmail(email) {
            this.email = email;
        }

        function addEntityUserGroup(userGroup) {
            this.userGroups = this.userGroups || [];

            if (userGroup && userGroup.id) {
                this.userGroups.push({id: userGroup.id});
            }
        }
    }

    function getUserInviteObject(user, dataGroups, allActions, organisationUnits, dataEntryRestrictions) {
        var inviteObject = getInviteObject();
        var selectedDataGroups = getSelectedDataGroups(user, dataGroups);
        var actions = getActionsForGroups(user, selectedDataGroups, allActions);
        //Add the usergroups to the invite object
        selectedDataGroups.forEach(function (dataGroup) {

            inviteObject.userGroups = inviteObject.userGroups.concat(dataGroup.userGroups.map(function (userGroup) {
                return {id: userGroup.id};
            }));
        });
        Object.keys(user.dataGroups).forEach(function (dataGroup) {
            if (user.userType.name && dataEntryRestrictions && user.dataGroups[dataGroup].access === true && user.dataGroups[dataGroup].entry === true) {
                var dataEntryUserRoles = dataEntryRestrictions[user.userType.name][dataGroup] || [];
                dataEntryUserRoles.forEach(function (dataEntryUserRole) {
                    var userRoleId = dataEntryUserRole.userRoleId;
                    if (userRoleId) {
                        inviteObject.userCredentials.userRoles.push({id: userRoleId});
                    }
                });
            }
        });

        //Add the user actions to the invite object
        actions.forEach(function (action) {
            if (action.userRoleId) {
                inviteObject.userCredentials.userRoles.push({id: action.userRoleId});
            }
        });

        organisationUnits = (Array.isArray(organisationUnits) && organisationUnits) || [];

        inviteObject.organisationUnits = (organisationUnits).map(function (orgUnit) {
            return {id: orgUnit.id};
        });
        inviteObject.dataViewOrganisationUnits = organisationUnits.map(function (orgUnit) {
            return {id: orgUnit.id};
        });

        inviteObject.addEmail(user.email);

        return inviteObject;
    }

    function getSelectedActions(user) {
        var userActions = (user && user.userActions) || [];

        return Object.keys(userActions).filter(function (key) {
            return this[key];
        }, userActions);
    }

    function getSelectedDataGroupNames(user) {
        var dataGroups = (user && user.dataGroups) || {};
        return Object.keys(dataGroups).filter(function (key) {
            return this[key] && this[key].access === true;
        }, dataGroups);
    }

    function getSelectedDataGroups(user, dataGroups) {
        var selectedDataGroupNames = getSelectedDataGroupNames(user);

        return (dataGroups || []).filter(function (dataGroup) {
            return selectedDataGroupNames.indexOf(dataGroup.name) >= 0;
        });
    }

    function getActionsForGroups(user, selectedDataGroups, actions) {
        var selectedActions = getSelectedActions(user);

        return selectedDataGroups.map(function (dataGroup) {
            return actions.map(function (action) {

                if (action.typeDependent === true) {
                    action.userRole = action.userRole.replace(/{{.+}}/, dataGroup.name);
                }

                dataGroup.userRoles.forEach(function (userRole) {
                    if (action.userRole === userRole.name) {
                        action.userRoleId = userRole.id;
                    }
                });

                return action;
            });
        })
        .reduce(function (actions, current) {
            if (angular.isArray(actions)) { actions = []; }

            return actions.concat(current);
        }, actions)
        .filter(function (action) {
            if (((selectedActions.indexOf(action.name) >= 0) || action.default === true) && isRequiredDataStreamSelected(action.dataStream, selectedDataGroups)) {
                return true;
            }
            return false;
        });
    }

    function isRequiredDataStreamSelected(dataGroupNames, selectedDataGroups) {
        if (Array.isArray(dataGroupNames) && dataGroupNames.length > 0) {
            return selectedDataGroups.reduce(function (curr, dataGroup) {
                return dataGroupNames.indexOf(dataGroup.name) >= 0 || curr;
            }, false);
        }
        return true;
    }

    function inviteUser(inviteData) {
        if (!angular.isObject(inviteData) && !null) {
            return $q.reject('Invalid invite data');
        }

        return Restangular
            .all('users')
            .all('invite')
            .post(inviteData)
            .then(function (response) {
                if (response.status !== 'SUCCESS' ||
                    response.importCount.imported !== 1 ||
                    response.importCount.updated !== 0 ||
                    response.importCount.ignored !== 0 ||
                    response.importCount.ignored !== 0) {
                    return $q.reject('Invite response not as expected');
                }
                return Restangular
                    .all('users')
                    .get(response.lastImported);
            })
            .catch(function (error) {
                if (angular.isString(error)) {
                    return $q.reject(error);
                }
                return $q.reject('Invite failed');
            });
    }

    function verifyInviteData(inviteObject) {
        if (verifyEmail(inviteObject.email) && verifyOrganisationUnits(inviteObject) &&
            verifyUserRoles(inviteObject.userCredentials) && verifyUserGroups(inviteObject.userGroups)) {
            return true;
        }
        return false;
    }

    function verifyEmail(email) {
        if (email) {
            return true;
        }
        return false;
    }

    function verifyOrganisationUnits(inviteObject) {
        if ((inviteObject.organisationUnits.length > 0 && inviteObject.organisationUnits[0].id) &&
            inviteObject.dataViewOrganisationUnits.length > 0 &&  inviteObject.dataViewOrganisationUnits[0].id) {
            return true;
        }
        return false;
    }

    function verifyUserRoles(userCredentials) {
        if (userCredentials && userCredentials.userRoles && userCredentials.userRoles.length > 0) {
            return true;
        }
        return false;
    }

    function verifyUserGroups(groups) {
        if (Array.isArray(groups) && groups.length > 0) {
            return true;
        }
        return false;
    }

    function saveUserLocale(username, locale) {
        if (username === undefined || username === '') {
            throw new Error('Username required');
        }

        if (locale === undefined || locale === '') {
            throw new Error('Locale required');
        }

        return Restangular.one('userSettings')
            .one('keyUiLocale')
            .post(undefined, locale, {user: username}, {'Content-Type': 'text/plain'})
            .then(function () {
                return locale;
            });
    }

    function getUserLocale(userName) {
        var deferred = $q.defer();

        Restangular
            .all('userSettings')
            .get('keyUiLocale', {user: userName})
            .then(function (locale) {
                deferred.resolve({
                    name: locale,
                    code: locale
                });
            })
            .catch(function () {
                deferred.resolve(undefined);
            });

        return deferred.promise;
    }

    function getUser(userId) {
        return Restangular
            .all('users')
            .get(userId, {
                fields: [':all', 'userCredentials[id,code,disabled,userRoles,catDimensionConstraints,cogsDimensionConstraints]'].join(',')
            });
    }

    function updateUser(userToUpdate, userGroups) {
        return getUserEntity(userToUpdate).then(function (userEntity) {
            var removedUserGroupPromises;
            var addedUserGroupPromises;
            var userAdminGroupName = userEntity && userEntity.userAdminUserGroup && userEntity.userAdminUserGroup.name;

            userEntity = userEntity || {};

            if (hasUserRole(userToUpdate, {name: 'User Administrator'})) {
                if (userEntity && userEntity.userAdminUserGroup && !hasUserGroup(userToUpdate, userEntity.userAdminUserGroup)) {
                    userGroups.push(userEntity.userAdminUserGroup);
                }
            } else {
                userGroups = userGroups.filter(function (userGroup) {
                    return userGroup.name !== userAdminGroupName;
                });
            }

            addedUserGroupPromises = getUserGroupsToAdd(userToUpdate.userGroups || [], userGroups).map(function (userGroup) {
                return addUserGroup(userGroup.id, userToUpdate.id);
            });
            removedUserGroupPromises = getUserGroupsToRemove(userToUpdate.userGroups || [], userGroups).map(function (userGroup) {
                return removeUserGroup(userGroup.id, userToUpdate.id);
            });

            return $q.all([addedUserGroupPromises, removedUserGroupPromises, userToUpdate.save()])
                .then(function () {
                    if (hasUserRole(userToUpdate, {name: 'User Administrator'})) {
                        if (!hasUserGroup(userToUpdate, userEntity.userAdminUserGroup)) {
                            userToUpdate.userGroups.push(userEntity.userAdminUserGroup);
                        }
                    } else {
                        userToUpdate.userGroups = (userToUpdate.userGroups || []).filter(function (userGroup) {
                            return userGroup.name !== userAdminGroupName;
                        });
                    }
                });
        });
    }

    function getUserGroupsToAdd(oldUserGroups, newUserGroups) {
        var oldUserGroupIds = _.pluck(oldUserGroups, 'id');

        return (newUserGroups || []).filter(function (userGroup) {
            return oldUserGroupIds.indexOf(userGroup.id) === -1;
        });
    }

    function getUserGroupsToRemove(oldUserGroups, newUserGroups) {
        var newUserGroupIds = _.pluck(newUserGroups, 'id');

        return (oldUserGroups || []).filter(function (userGroup) {
            return newUserGroupIds.indexOf(userGroup.id) === -1;
        });
    }

    function addUserGroup(userGroupId, userId) {
        return Restangular
            .one(['userGroups', userGroupId, 'users'].join('/'))
            .post(userId);
    }

    function removeUserGroup(userGroupId, userId) {
        return Restangular
            .one(['userGroups', userGroupId, 'users', userId].join('/'))
            .remove();
    }

    function getUserEntity(user) {
        var organisationUnit = user && Array.isArray(user.organisationUnits) && user.organisationUnits[0] || undefined;

        return $q.all([
                partnersService.getPartners(organisationUnit),
                agenciesService.getAgencies(organisationUnit),
                interAgencyService.getUserGroups(organisationUnit)
            ])
            .then(function (responses) {
                return (responses[0] || [])
                    .concat(responses[1] || [])
                    .concat([responses[2]]);
            })
            .then(function (partnersAndAgencies) {
                return partnersAndAgencies.reduce(function (current, partnerAgency) {
                    if (partnerAgency && partnerAgency.userUserGroup && partnerAgency.userAdminUserGroup &&
                        partnerAgency.userUserGroup.name && partnerAgency.userAdminUserGroup.id &&
                        hasUserGroup(user, partnerAgency.userUserGroup)) {
                        return partnerAgency;
                    }
                    return current;
                }, undefined);
            });
    }

    function hasUserGroup(user, userGroupToCheck) {
        return (user.userGroups || []).reduce(function (current, userGroup) {
            return current || (userGroup.name === userGroupToCheck.name);
        }, false);
    }

    function hasUserRole(user, userRoleToCheck) {
        return (user && user.userCredentials && user.userCredentials.userRoles || []).reduce(function (current, userRole) {
            return current || (userRole.name === userRoleToCheck.name);
        }, false);
    }
}
userService.$inject = ['$q', 'Restangular', '_', 'partnersService', 'agenciesService', 'interAgencyService'];

angular.module('PEPFAR.usermanagement').service('errorHandler', errorHandlerService);

function errorHandlerService($q, $log, notify, SETTINGS) {
    var errorMessages = {
        404: 'Requested resource was not found'
    };
    var sv = this;

    this.error = error;
    this.warning = warning;
    this.debug = debug;
    this.message = message;

    this.errorFn = function (message) {
            return function () {
                return sv.error(message);
            };
        };

    this.warningFn = function (message) {
        return function () {
            return sv.warning(message);
        };
    };

    this.debugFn = function (message) {
        return function () {
            return sv.debug(message);
        };
    };

    function error(message) {
        if (message.status) {
            $log.error(errorMessages[message.status]);
            notify.error(errorMessages[message.status]);
        } else {
            $log.error(message);
            notify.error(message);
        }
        return $q.reject(message);
    }

    function warning(message) {
        if (message.status) {
            $log.error(errorMessages[message.status]);
            notify.warning(errorMessages[message.status]);
        } else {
            $log.error(message);
            notify.warning(message);
        }
        return $q.reject(message);
    }

    function debug(message) {
        if (!SETTINGS.debug) { return $q.reject(message); }

        Array.prototype.forEach.call(arguments, function (message) {
            $log.debug(message);
        });

        return $q.reject(message);
    }

    function message(msg) {
        var separator = ' ';

        if (Array.isArray(msg)) {
            return msg.join(separator);
        }
        return msg;
    }
}
errorHandlerService.$inject = ['$q', '$log', 'notify', 'SETTINGS'];

angular.module('PEPFAR.usermanagement').factory('currentUserService', currentUserService);

function currentUserService($q, Restangular, errorHandler) {
    var currentUserPromise;

    initialise();
    return {
        getCurrentUser: getCurrentUser
    };

    function initialise() {
        currentUserPromise = $q.all([requestCurrentUser(), requestUserAuthorities()])
            .then(function (responses) {
                var currentUser = responses[0];
                var userAuthorities = responses[1];

                currentUser.authorities = userAuthorities;

                //Add convenience methods to the userObject
                currentUser.hasAllAuthority = hasAllAuthority.bind(currentUser.authorities);
                currentUser.hasUserRole = hasUserRole.bind(currentUser);
                currentUser.isUserAdministrator = isUserAdministrator.bind(currentUser);
                currentUser.isGlobalUser = isGlobalUser;

                return currentUser;
            }, errorHandler.errorFn('Failed to load the current user data'));
    }

    function requestCurrentUser() {
        return Restangular.one('me').withHttpConfig({cache: true}).get();
    }

    function requestUserAuthorities() {
        return Restangular.all('me').withHttpConfig({cache: true}).get('authorization');
    }

    function getCurrentUser() {
        return currentUserPromise;
    }

    //*************************************************************************
    // User functions
    function hasAllAuthority() {
        return this.indexOf('ALL') >= 0;
    }

    function hasUserRole(userRoleName) {
        if (!this.userCredentials || !this.userCredentials.userRoles) {
            return false;
        }

        return this.userCredentials.userRoles.some(function (userRole) {
            return userRoleName === userRole.name;
        });
    }

    function isUserAdministrator() {
        return this.hasUserRole('User Administrator');
    }

    function isGlobalUser() {
        var organisationUnit = this.organisationUnits && this.organisationUnits[0];

        return organisationUnit && organisationUnit.name === 'Global';
    }
}
currentUserService.$inject = ['$q', 'Restangular', 'errorHandler'];

angular.module('PEPFAR.usermanagement').controller('noAccessController', noAccessController);

function noAccessController($stateParams) {
    var vm = this;

    vm.message = $stateParams.message || 'Your user account does not seem to have the right permissions to access this functionality.';
}
noAccessController.$inject = ['$stateParams'];

//http://localhost:8080/dhis/api/categories.json?filter=name:eq:Funding%20Mechanism
angular.module('PEPFAR.usermanagement').factory('categoriesService', categoriesService);

function categoriesService(Restangular, $q) {
    var categoriesEndPoint = Restangular.one('categories');

    return {
        getDimensionConstraint: getDimensionConstraint
    };

    function getDimensionConstraint() {
        var queryParams = {
            filter: 'name:eq:Funding Mechanism',
            paging: false
        };

        return categoriesEndPoint.get(queryParams)
            .then(attemptToExtractFundingMechanismCategory);
    }

    function attemptToExtractFundingMechanismCategory(response) {
        if (Array.isArray(response.categories) && response.categories.length === 1) {
            return response.categories[0];
        }
        return $q.reject('More than 1 category with Funding Mechanism found');
    }
}
categoriesService.$inject = ['Restangular', '$q'];

angular.module('d2-headerbar', []).directive('headerBar', headerBar);

/**
 * @ngdoc directive
 * @name headerBar
 *
 * @restrict E
 * @scope
 *
 * @description
 *
 * This directive represents the headerbar in dhis
 *
 * @example
 This example specifies the most basic usage of the detailsbox. It passes an object and displays it's properties.

 <example module="d2-headerbar">
 <file name="index.html">
    <header-bar logo="https://www.dhis2.org/sites/all/themes/dhis/logo.png"></header-bar>
 </file>
 </example>
 */
function headerBar() {
    return {
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            headerTitle: '=title',
            headerLink: '=link',
            headerLogo: '=logo'
        },
        templateUrl: 'headerbar/headerbar.html'
    };
}

angular.module('PEPFAR.usermanagement').factory('notify', function () {
    var toastr;

    initialise();
    return {
        success: success,
        error: error,
        warning: warning
    };

    function initialise() {
        var toastrOptions;

        if (window.toastr) {
            toastr = window.toastr;
            toastrOptions = window.toastr.options;
            toastrOptions.positionClass = 'toast-top-right';
            toastrOptions.timeOut = 0;
            toastrOptions.extendedTimeOut = 0;
            toastrOptions.closeButton = true;
            toastrOptions.tapToDismiss = false;

            return window.toastr;
        }
        throw new Error('Toastr.js library does not seem to be loaded.');
    }

    function success(message) {
        toastr.success(message, undefined, {timeOut: 2500, extendedTimeOut: 2500});
    }

    function error(message) {
        toastr.error(message);
    }

    function warning(message) {
        toastr.warning(message, undefined, {timeOut: 2500, extendedTimeOut: 2500});
    }
});

angular.module('PEPFAR.usermanagement').factory('interAgencyService', interAgencyService);

function interAgencyService($q, Restangular, errorHandler) {
    var userGroupEndPoint = Restangular.one('userGroups').withHttpConfig({cache: true});

    return {
        getUserGroups: getUserGroups
    };

    function getUserGroups(organisationUnit) {
        var organisationUnitName;
        if (!(organisationUnit && organisationUnit.name)) {
            return $q.reject('No organisation unit found on the current user');
        }
        organisationUnitName = organisationUnit.name;

        return $q.all([
            getUserUserGroup(organisationUnitName),
            getAdminUserGroup(organisationUnitName),
            getMechUserGroup(organisationUnitName)
        ]).then(function (responses) {

            errorHandler.debug(
                'The following inter-agency user groups were found:',
                'for users:', responses[0],
                'for usermanagement:', responses[1],
                'for mechanisms:', responses[2]
            );

            return {
                userUserGroup: responses[0],
                userAdminUserGroup: responses[1],
                mechUserGroup: responses[2]
            };
        }, errorHandler.errorFn('Unable to load all the inter agency user groups'));
    }

    function getUserUserGroup(organisationUnitName) {
        var filter = ['name', 'like', ['OU', organisationUnitName, 'Country', 'team'].join(' ')].join(':');
        var filterRegEx = new RegExp(['OU', '.+?', 'Country', 'team'].join(' '), 'i');

        return requestUserGroups(filter)
            .then(function (userGroups) {
                return filterGroupsOnName(userGroups, filterRegEx);
            });
    }

    function getAdminUserGroup(organisationUnitName) {
        var filter = ['name', 'like', ['OU', organisationUnitName, 'user', 'administrators'].join(' ')].join(':');
        var filterRegEx = new RegExp(['OU', '.+?', 'user', 'administrators'].join(' '), 'i');

        return requestUserGroups(filter)
            .then(function (userGroups) {
                return filterGroupsOnName(userGroups, filterRegEx);
            });
    }

    function getMechUserGroup(organisationUnitName) {
        var filter = ['name', 'like', ['OU', organisationUnitName, 'all', 'mechanisms'].join(' ')].join(':');
        var filterRegEx = new RegExp(['OU', '.+?', 'all', 'mechanisms'].join(' '), 'i');

        return requestUserGroups(filter)
            .then(function (userGroups) {
                return filterGroupsOnName(userGroups, filterRegEx);
            });
    }

    function requestUserGroups(filter) {
        return userGroupEndPoint
            .get({
                fields: 'id,name',
                filter: filter,
                paging: false
            });
    }

    function filterGroupsOnName(userGroups, filterRegEx) {
        userGroups = userGroups.userGroups || [];

        return userGroups.reduce(function (current, userGroup) {
            if (filterRegEx.test(userGroup.name)) {
                return userGroup;
            }
            return current;
        }, undefined);
    }
}
interAgencyService.$inject = ['$q', 'Restangular', 'errorHandler'];

angular.module('PEPFAR.usermanagement').factory('userFormService', userFormService);

function userFormService(userService) {
    return {
        getValidations: getValidations
    };

    function getValidations() {
        return {
            dataGroupsInteractedWith: dataGroupsInteractedWith(),
            validateDataGroups: validateDataGroups,
            isRequiredDataStreamSelected: isRequiredDataStreamSelected
        };
    }

    function dataGroupsInteractedWith() {
        var regex = /^dataStream.+$/g;
        var dataStreamIds;
        var dataStreamInteractedWith = false;

        return function (form) {
            var groups = dataStreamIds || (dataStreamIds = Object.keys(form).filter(function (key) {
                return regex.test(key);
            }));

            groups.forEach(function (key) {
                if (form[key] && form[key].$dirty) { dataStreamInteractedWith = true; }
            });

            return dataStreamInteractedWith;
        };
    }

    function validateDataGroups(dataGroups) {
        var valid = false;

        valid = Array.prototype.map.call(Object.keys(dataGroups), function (value) {
            return dataGroups[value] && dataGroups[value].access === true;
        }).reduce(function (valid, curr) {
                return valid || curr;
            }, valid);

        return valid;
    }

    function isRequiredDataStreamSelected(dataGroupNames, user, dataGroups) {
        var selectedDataGroups = userService.getSelectedDataGroups(user, dataGroups);

        if (Array.isArray(dataGroupNames) && dataGroupNames.length > 0) {
            return selectedDataGroups.reduce(function (curr, dataGroup) {
                return dataGroupNames.indexOf(dataGroup.name) >= 0 || curr;
            }, false);
        }
        return true;
    }
}
userFormService.$inject = ['userService'];

angular.module('PEPFAR.usermanagement').directive('userStatus', userStatusDirective);

function userStatusDirective() {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            user: '='
        },
        templateUrl: 'userstatus/userstatus.html',
        link: linkFn
    };

    function linkFn() {

    }
}

angular.module('PEPFAR.usermanagement').factory('organisationUnitService', organisationUnitService);

function organisationUnitService(Restangular, _) {
    return {
        getOrganisationUnitsForLevel: getOrganisationUnitsForLevel
    };

    function getOrganisationUnitsForLevel(level) {
        return Restangular
            .one('organisationUnits').withHttpConfig({cache: true})
            .get({
                level: level || 1
            })
            .then(function (response) {
                return response.organisationUnits || [];
            })
            .then(function (organisationUnits) {
                return _.sortBy(organisationUnits, 'name');
            });
    }
}
organisationUnitService.$inject = ['Restangular', '_'];

angular.module('PEPFAR.usermanagement').directive('organisationUnitSelect', organisationUnitSelectDirective);

function organisationUnitSelectDirective(organisationUnitService, $translate, errorHandler) {
    return {
        restrict: 'E',
        replace: true,
        scope: true,
        templateUrl: 'organisationunits/organisation-select.html',
        link: function (scope) {
            scope.selectbox = {
                items: [],
                placeholder: $translate.instant('Select an organisation unit')
            };

            errorHandler.debug('Loading organisation units for level: 3');
            organisationUnitService.getOrganisationUnitsForLevel(3)
                .then(function (organisationUnits) {
                    scope.selectbox.items = organisationUnits;
                });
        }
    };
}
organisationUnitSelectDirective.$inject = ['organisationUnitService', '$translate', 'errorHandler'];
